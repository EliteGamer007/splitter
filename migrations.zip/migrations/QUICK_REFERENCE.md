# Quick Command Reference - Neon Migration

## 🎯 One-Command Migration (RECOMMENDED)

```bash
# Replace with your actual Neon connection string
psql "postgresql://username:password@ep-xxx-xxx.region.neon.tech:5432/dbname?sslmode=require" \
  -f migrations/000_master_schema.sql
```

## ✅ Verify Success

```bash
psql "your-connection-string" -f migrations/verify_migration.sql
```

## 🔧 Neon Connection String Format

Get from Neon Dashboard → Connection Details → Copy connection string:

```
postgresql://[user]:[password]@[host].neon.tech/[database]?sslmode=require
```

Example:
```
postgresql://splitter_user:abc123xyz@ep-cool-water-12345.us-east-2.neon.tech/splitter_db?sslmode=require
```

## 📝 pgAdmin Connection Settings

**General Tab:**
- Name: `Neon Splitter`

**Connection Tab:**
- Host: `ep-xxx-xxx.region.neon.tech` (from connection string)
- Port: `5432`
- Database: `your_database_name`
- Username: `your_username`
- Password: `your_password`

**SSL Tab:**
- SSL Mode: `Require`

**Then:**
1. Tools → Query Tool
2. Open File → `000_master_schema.sql`
3. Press F5 or Execute button

## 🔍 Quick Verification Queries

```sql
-- Count tables (should be 15)
SELECT COUNT(*) FROM information_schema.tables 
WHERE table_schema = 'public';

-- Check users table has auth columns
SELECT column_name FROM information_schema.columns 
WHERE table_name='users' 
AND column_name IN ('email', 'password_hash', 'role');

-- Should return 3 rows
```

## 🐛 Common Issues

**Issue:** `connection refused`
**Fix:** Check host name and port, ensure SSL mode is enabled

**Issue:** `authentication failed`
**Fix:** Verify username and password from Neon dashboard

**Issue:** `relation already exists`
**Fix:** Database not empty. Either drop all tables or use 004_consolidated_fixes.sql

## 📊 What Success Looks Like

```
✓ PASS - Found 15 tables
✓ users.email exists
✓ users.password_hash exists
✓ users.role exists
✓ PASS - Found 20+ indexes
✓ Triggers created
```

## 📁 File Summary

| File | Use Case | Safe to Re-run? |
|------|----------|-----------------|
| `000_master_schema.sql` | Fresh database | ❌ No (use once) |
| `004_consolidated_fixes.sql` | Existing database | ✅ Yes |
| `verify_migration.sql` | Check success | ✅ Yes (read-only) |

## 🚀 After Migration

Update your `.env`:
```env
DB_HOST=ep-xxx-xxx.region.neon.tech
DB_PORT=5432
DB_USER=your_username
DB_PASSWORD=your_password
DB_NAME=your_database
```

Test app connection:
```bash
cd splitter
go run cmd/server/main.go
```

Should see: `Database connection established successfully`

---

**That's it! Your database is ready for data migration.**
