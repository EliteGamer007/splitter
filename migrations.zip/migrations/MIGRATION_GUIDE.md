# Migration Guide for Neon Cloud Database

## 🚨 Important: Migration File Issues

Your original migration files had conflicts:
- **TWO files numbered 002** (duplicate migration numbers)
- **Three files adding the same columns** (002, 002, 003 all add email/password_hash)
- This would cause errors when running migrations in sequence

## ✅ Solution: Two Approaches

### **RECOMMENDED: Fresh Database (Neon/Cloud)**

If you're setting up a **NEW database** on Neon (no existing data):

```bash
# Use the master schema file - contains everything in one clean file
psql "postgresql://your-neon-connection-string" -f migrations/000_master_schema.sql
```

**Benefits:**
- ✅ Single file, no conflicts
- ✅ All tables, indexes, and triggers included
- ✅ Clean, tested schema
- ✅ Matches your application code exactly

---

### **Alternative: Incremental Migration (Existing Database)**

If you already have data in a database and need to upgrade:

```bash
# Run in order:
psql "connection-string" -f migrations/001_initial_schema.sql
psql "connection-string" -f migrations/004_consolidated_fixes.sql
```

**Skip these conflicting files:**
- ❌ `002_add_admin_and_messaging.sql`
- ❌ `002_add_password_auth.sql`  
- ❌ `003_add_email_password_columns.sql`

---

## 📋 Complete Schema Checklist

After running migrations, verify these tables exist:

### Core Tables (Currently in Use)
- [x] `users` - User accounts
- [x] `follows` - Follow relationships  
- [x] `posts` - User posts/content
- [x] `interactions` - Likes and reposts
- [x] `bookmarks` - Saved posts
- [x] `message_threads` - DM conversations
- [x] `messages` - Individual messages
- [x] `moderation_requests` - Moderator applications
- [x] `admin_actions` - Audit log

### Federation Tables (Future Use)
- [x] `remote_actors` - Federated users
- [x] `inbox_activities` - Incoming federation
- [x] `outbox_activities` - Outgoing federation
- [x] `activity_deduplication` - Duplicate prevention

### Moderation Tables  
- [x] `reports` - Content reports
- [x] `blocked_domains` - Defederated servers
- [x] `instance_reputation` - Server reputation
- [x] `federation_failures` - Circuit breaker

### Supporting Tables
- [x] `user_keys` - Multi-device support
- [x] `media` - Post attachments

---

## 🔧 Connecting to Neon via pgAdmin

1. **Get your Neon connection string** from dashboard:
   ```
   postgresql://username:password@host.region.neon.tech/dbname?sslmode=require
   ```

2. **In pgAdmin:**
   - Right-click "Servers" → Register → Server
   - **General Tab:** Name: "Neon Splitter"
   - **Connection Tab:**
     - Host: `[from connection string]`
     - Port: `5432`
     - Database: `[your db name]`
     - Username: `[from connection string]`
     - Password: `[from connection string]`
   - **SSL Tab:** SSL Mode: `Require`

3. **Run the master schema:**
   - Connect to your database
   - Tools → Query Tool
   - Open `000_master_schema.sql`
   - Execute (F5)

---

## 🧪 Verify Migration Success

After running migrations, check that everything works:

```sql
-- Check all tables exist
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public' 
ORDER BY table_name;

-- Verify users table has all required columns
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_name = 'users'
ORDER BY ordinal_position;

-- Check indexes
SELECT indexname, tablename 
FROM pg_indexes 
WHERE schemaname = 'public'
ORDER BY tablename, indexname;

-- Verify triggers
SELECT trigger_name, event_object_table 
FROM information_schema.triggers
WHERE trigger_schema = 'public';
```

Expected results:
- **15 tables** total
- **Users table** should have: id, username, email, password_hash, did, role, moderation_requested, etc.
- **20+ indexes** for performance
- **2 triggers** for auto-updating timestamps

---

## 🎯 Application Configuration

After database migration, update your `.env` file with Neon credentials:

```env
# Neon Database
DB_HOST=your-project.region.neon.tech
DB_PORT=5432
DB_USER=your_username
DB_PASSWORD=your_password
DB_NAME=your_database
DB_SSL_MODE=require

# App Config
PORT=8080
ENV=production
JWT_SECRET=your-secure-secret-here-change-this
BASE_URL=https://your-domain.com
```

---

## 🐛 Troubleshooting

### "relation already exists" error
- If using 000_master_schema.sql on a fresh database, this shouldn't occur
- If upgrading existing database, use 004_consolidated_fixes.sql instead

### "column already exists" error  
- The 004 migration uses `IF NOT EXISTS` checks
- Safe to run multiple times

### SSL connection errors
- Neon requires SSL: add `?sslmode=require` to connection string
- pgAdmin: Set SSL Mode to "Require" in connection settings

### Authentication errors
- Double-check username and password from Neon dashboard
- Some connection strings use URL encoding for special characters

---

## 📝 Summary

**For Neon Cloud Database (Recommended):**
```bash
psql "your-neon-connection-string?sslmode=require" -f migrations/000_master_schema.sql
```

**For existing local database:**
```bash
psql -U postgres -d splitter -f migrations/004_consolidated_fixes.sql
```

**Files Created:**
- ✅ `000_master_schema.sql` - Complete schema for fresh databases
- ✅ `004_consolidated_fixes.sql` - Safe upgrade for existing databases
- 📖 `MIGRATION_GUIDE.md` - This guide

**Files to Ignore:**
- ❌ Don't use 002 or 003 migration files (they conflict)
